//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Copyright (C) Microsoft Corporation. All Rights Reserved.
//
// Microsoft Health Solutions Group.
//
//----------------------------------------------------------------------------

import sys, subprocess, os, string

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print "USAGE: %s [file.pfx]" % sys.argv[0]
        sys.exit(1)
    else:
        p = os.path.splitext(sys.argv[1])
        if p[1] != ".pfx":
            print "%s does not end in .pfx!" % sys.argv[1]
            sys.exit(1)
        pemname = "%s.pem" % p[0]
        fpname = "%s.fp" % p[0]
        retcode = subprocess.call(
            ["openssl", "pkcs12", "-in",
             sys.argv[1], "-out", pemname, "-nodes"])
	if retcode != 0:
	   print "Error while trying to create %s" % pemname
	   sys.exit(1)
	print "Created %s." % pemname
	
        p1 = subprocess.Popen(
            ["openssl", "x509", "-in", pemname, "-noout", "-pubkey", "-fingerprint"], stdout=subprocess.PIPE)
	output = p1.communicate()[0]
	lines = output.splitlines()
	matchmaker = "SHA1 Fingerprint="
	found = False
	for line in lines:
		f = line.find(matchmaker)
		if f != -1:
			fp = line[f+len(matchmaker):].replace(":","")
			file(fpname, "w").write(fp)
			found = True
	if not found:
		print "Cannot find fingerprint"
		sys.exit(1)
	print "Created %s." % fpname
	sys.exit(0)
        
else:
    raise Exception("Don't import this file!")
