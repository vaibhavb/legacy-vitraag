To convert the .pfx files to a .pem and a .fp file just run the convertpfx.py script with the .pfx file you want to convert as the one and only argument. 
