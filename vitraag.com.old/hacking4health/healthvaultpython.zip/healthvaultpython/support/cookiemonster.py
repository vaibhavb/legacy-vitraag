//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Copyright (C) Microsoft Corporation. All Rights Reserved.
//
// Microsoft Health Solutions Group.
//
//----------------------------------------------------------------------------

import os
class CookieMonster:
	def __init__(self, filename):
		self.filename = filename
		if not os.path.exists(filename):
			open(filename, 'w').close()
			self.hascookies = False
		else:
			lines = open(filename, 'r').readlines()
			if len(lines) != 3:
				self.hascookies = False
			else:	
				self.hascookies = True
				self.sessiontoken = lines[0].rstrip()
				self.sharedsecret = lines[1].rstrip()
				self.usertoken = lines[2].rstrip()

	def are_the_cookies_freshly_baked(self, hv, user):
		res = hv.getApplicationSettings(user)
		return not res.isError

	def fill_cookie_jar(self, cookies):
		fd = open(self.filename, 'w')	
		fd.write("%s\r\n%s\r\n%s\r\n" % (
			cookies['sessiontoken'],
			cookies['sharedsecret'],
			cookies['usertoken']
		))
		fd.flush()
		fd.close()

	def get_some_fresh_cookies(self):
		if not self.hascookies:
			raise Exception("CookieMonster doesn't have fresh cookies! :-(")
		return {"usertoken":self.usertoken,
			"sharedsecret":self.sharedsecret,
			"sessiontoken":self.sessiontoken}	
		
