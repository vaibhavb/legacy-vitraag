This code requires:
	
- Python (only tested 2.6, anything >= 3.x is NOT going to work!!)
	
- Python M2Crypto library (MIT licensed)

- Python Mechanize library (BSD licensed) 


This code was written for testing of the HealthVault platform
of the Microsoft Health Solutions Group. All rights pertaining to this code are hereby declared
to belong at Microsoft. For more information contact jim.oleary [at] microsoft.com or vaibhavb [at] microsoft.com

Just configure the hv.ini correctly and start playing around with the HV platform, or use it in your web-application.

--
Please use this library in conjunction with TrailX libary --
http://code.google.com/p/pyhealthvault/

Users of this library are encourage to make an open source version and improve the TrialX (appliedinformatics inc.) library.