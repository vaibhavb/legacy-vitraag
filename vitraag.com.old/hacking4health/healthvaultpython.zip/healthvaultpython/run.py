//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Copyright (C) Microsoft Corporation. All Rights Reserved.
//
// Microsoft Health Solutions Group.
//
//----------------------------------------------------------------------------

import ConfigParser, time
import healthvault, support
from healthvault import things

def readconfig():
	inifile = open('hv.ini', 'r')
	parser = ConfigParser.SafeConfigParser()
	parser.readfp(inifile)
	options = ['shellredirecturl', 'serviceurl', 'applicationid', 'pemfile', 'fpfile', 'cookiejar']
	hvsetoptions = {}
	for option in options:
		try:
			hvsetoptions[option] = parser.get("HealthVault", option)
		except:
			raise Exception("Error while trying to get option %s" % option)

	try:
		liveusername = parser.get("LiveUser", "username")
		livepassword = parser.get("LiveUser", "password")
	except:
		raise Exception("Error while trying to get LiveUser username and/or password option")
	inifile.close()
	return {"hvsetoptions":hvsetoptions,"livecredentials":(liveusername, livepassword)}

def run():
	options = readconfig()
	hvsetoptions = options["hvsetoptions"]
	livecreds = options["livecredentials"]
	hv = healthvault.HealthVault(**hvsetoptions)
	user = hv.getWindowsLiveUser(livecreds[0], livecreds[1])

	"""
	Try to find saved session tokens and quickly check if 
	both the user credential and the application credential
	are still valid. This saves us about 60-90 seconds upon
	each run. CookieMonster will check for the existance of
	saved session tokens (cookies) and also if the tokens are
	still valid. If not CookieMonster will go on a hunt for
	new cookies!

	(chorus)
	THE BBBBBBBBBBBBBB is for......
	THE CCCCCCCCCCCCCC is for COOOOOOOOOKKKIIIEEEEE!!
	THE DDDDDDDDDD.......
	""" 
	hv.acquireSessionToken2()	

	return
	cookiemonster = support.CookieMonster(hvsetoptions["cookiejar"])
	fresh_cookies = False
	if cookiemonster.hascookies:
		print "Cookiemonster has found some cookies!"
		cookies = cookiemonster.get_some_fresh_cookies()
		hv.setSharedSecret(cookies["sharedsecret"])
		hv.setSessionToken(cookies["sessiontoken"])
		hv.setAuthenticated(True)
		user.setUserSessionToken(cookies["usertoken"])
		fresh_cookies = cookiemonster.are_the_cookies_freshly_baked(hv, user)
	
	if not fresh_cookies:	
		print "No fresh cookies found... Off to the cookie store!"

		# get session token for the application
		hv.acquireSessionToken()	
		print "Acquired sessiontoken for Application with id %s" % hv.applicationid
		
		# construct new WindowsLiveUser and get session token
		user.acquireUserSessionToken()
		print "Acquired usertoken for Windows Live ID with name %s" % user.username
		cookies = {
			"usertoken":user.getUserSessionToken(),
			"sessiontoken":hv.getSessionToken(),
			"sharedsecret":hv.getSharedSecret()}
		cookiemonster.fill_cookie_jar(cookies)
	else:
		print "The cookies seem to be fresh!"

	defaultrecordid = hv.getDefaultRecordForUser(user)
	print "The default record-id for %s is:\r\n\t%s" % (user.username, defaultrecordid)

	hv.getThings(user, defaultrecordid)
	#thing = things.TransformThingTest()
	#hv.putThings(user, defaultrecordid, [thing])	
	"""
	hv.getThings(user, defaultrecordid)
	hv.createOpenQuery(user, defaultrecordid)
	hv.getServiceDefinition()

	hv.getApplicationInfo(user)
	hv.updateApplication(user, "IOActive<![CDATA[<b>adsf</b>]]>", "http://toeter.com")

	thing = things.CCDFileThing('ExampleCCD.xml')
	thing = things.CCRFileThing('ExampleCCR.xml')
	thing = things.PasswordProtectedPackage()
	packagexml = thing.toxml()
	fd = open('idsoutput.txt', 'a')
	print "\r\n\r\n\r\n"
	for i in range(0, 10000):
		lasttime = time.time()
		id = hv.connectPackage("friendly name", "question??", defaultrecordid, packagexml)
		print id
		t = time.time()-lasttime
		fd.write("%s %s\r\n" % (id, t))
		fd.flush()
	fd.close()
	#hv.putThings(user, defaultrecordid, [thing])	
	#hv.sendMessage("floppp", "hallo", [{"name":"test", "email":"IOActive_hv1@live.com"}], user)
	"""
		

if __name__ == "__main__":
	run()
else:
	raise Exception("Don't import this file!")
