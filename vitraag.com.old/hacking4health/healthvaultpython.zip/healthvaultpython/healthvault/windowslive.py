//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Copyright (C) Microsoft Corporation. All Rights Reserved.
//
// Microsoft Health Solutions Group.
//
//----------------------------------------------------------------------------

import mechanize, urllib2, logging, sys

def urldecode(query):
   d = {}
   a = query.split('&')
   for s in a:
      if s.find('='):
         k,v = map(urllib2.unquote, s.split('='))
         try:
            d[k].append(v)
         except KeyError:
            d[k] = [v]
 
   return d

class RedirectHandler(mechanize._http.HTTPRedirectHandler):
	def redirect_request(self, newurl, req, fp, code, msg, headers):
		self.lastredirecturl = newurl
		return mechanize._http.HTTPRedirectHandler.redirect_request(self, newurl, req, fp, code, msg, headers)

class WindowsLiveUser():

	username = None
	password = None
	hv = None
	usertoken = None

	def __init__(self, hv, username, password):
		self.username = username
		self.password = password
		self.hv = hv

	def getUserSessionToken(self):
		return self.usertoken
	def setUserSessionToken(self, usertoken):
		self.usertoken = usertoken
	def acquireUserSessionToken(self):
		debug = False 
		actionurl = "%s?target=AUTH&targetqs=?appid=%s" % (self.hv.shellredirecturl, self.hv.applicationid)		
		if debug:
			print actionurl

		b = mechanize.Browser()
		#b.set_debug_redirects(True)
		#b.set_debug_responses(True)
		#b.set_debug_http(True)
		rdhandler = RedirectHandler()
		b._replace_handler("_redirect", rdhandler)
		#logger = logging.getLogger("mechanize")
		#logger.addHandler(logging.StreamHandler(sys.stdout))
		#logger.setLevel(logging.INFO)

		r = b.open(actionurl)
		if debug:
			print r.geturl()
		b.select_form(name="aspnetForm")
		b["ctl00$cphMainBody$txtEmail"] = self.username 
		r2 = b.submit()
		if debug:
			print r2.geturl()
		b.select_form(name="f1")
		b["passwd"] = self.password	
		r3 = b.submit()
		if debug:
			print r3.geturl()
		try:
			b.select_form(name="fmHF")
		except mechanize._mechanize.FormNotFoundError:
			raise Exception("ERROR while trying to log in Live user with username %s" % self.username)

		tokenname = "apptoken"
		try:
			r4 = b.submit()
			if debug:
				print r4.geturl()
		except:
			# XXX: localhost doesn't work mostly
			# this is if a user is already logged in
			tokenname = "wctoken"
		if tokenname == "wctoken":
			uri = rdhandler.lastredirecturl
		else:	
			uri = r4.geturl()
		uriparts = urldecode(uri)
		if tokenname not in uriparts or len(uriparts[tokenname]) is not 1:
			raise Exception("ERROR while trying to find user token after Live platform login")
		self.usertoken = uriparts[tokenname][0]
		
