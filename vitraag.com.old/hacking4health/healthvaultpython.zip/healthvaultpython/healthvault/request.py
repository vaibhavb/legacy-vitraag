//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Copyright (C) Microsoft Corporation. All Rights Reserved.
//
// Microsoft Health Solutions Group.
//
//----------------------------------------------------------------------------

import time, xml.etree.ElementTree as etree
import M2Crypto, base64, hashlib, hmac, StringIO

def parse_xmlns(file):

    events = "start", "start-ns"

    root = None
    ns_map = []

    for event, elem in etree.iterparse(file, events):

        if event == "start-ns":
            ns_map.append(elem)

        elif event == "start":
            if root is None:
                root = elem
            for prefix, uri in ns_map:
                elem.set("xmlns:" + prefix, uri)
            ns_map = []

    return etree.ElementTree(root)

class Request:

	methodversion = "1"
	language = "en" 
	country = "US"
	msg_ttl = "36000"
	msg_time = time.strftime("%Y-%m-%dT%H:%M:%SZ")
	version = "0.0.0.1"
	authentication = False 
	hmac = None
	infoxml = None
	recordid = None

	def __init__(self, hv, methodcall):
		self.methodcall = methodcall
		self.hv = hv

	def _buildxml(self):
		self.root = etree.Element("wc-request:request", 
			attrib={"xmlns:wc-request":"urn:com.microsoft.wc.request"})
		etree._namespace_map.update({"urn:com.microsoft.wc.request":"wc-request"})
		#,nsmpap={"adf":"urn:com.microsoft.wc-request"})
		#self.root = etree.Element("{urn:com.microsoft.wc.request#wc-request}request", nsmap={None:"urn:com.microsoft.wc.request","ns0":"wc-request"})
		self._buildauthxml()
		self._buildheaderxml()
		self._buildinfoxml()
		self._buildhmacxml()

	def _buildauthxml(self):
		if not self.authentication:
			return
		auth = etree.SubElement(self.root, "auth")
		self.hmac = etree.SubElement(auth, "hmac-data", attrib={"algName":"SHA1"})

	def _buildhmacxml(self):
		if not self.authentication:
			return
		if self.hmac is None:
			raise Exception("Error occurred... hmac is None")		
		
		# compute SHA1 hash over the <info> element and put it in the <header>
		infxml = self.infoxml if self.infoxml is not None else "<info />"
		computedhash = base64.b64encode(hashlib.sha1(infxml).digest())
		infohash = etree.SubElement(self.header, "info-hash")
		etree.SubElement(infohash, "hash-data", attrib={"algName":"SHA1"}).text = computedhash

		# compute HMAC with SHA1 over the <header element> and put it under <auth>
		data = etree.tostring(self.header)
		msghmac = hmac.new(self.hv.sharedsecret, '', hashlib.sha1)
		msghmac.update(data)
		self.hmac.text = base64.b64encode(msghmac.digest())
		return

	def _buildheaderxml(self):
		self.header = etree.SubElement(self.root, "header")
		self._addHeader("method", self.methodcall)
		self._addHeader("method-version", self.methodversion)
		if not self.authentication:
			self._addHeader("app-id", self.hv.applicationid)
		else:
			if self.recordid is not None:
				self._addHeader("record-id", self.recordid)
			authsession = etree.SubElement(self.header, "auth-session")
			etree.SubElement(authsession, "auth-token").text = self.hv.sessiontoken
			if self.usertoken is not None:
				etree.SubElement(authsession, "user-auth-token").text = self.usertoken
			
		self._addHeader("language", self.language)
		self._addHeader("country", self.country)
		self._addHeader("msg-time", self.msg_time)
		self._addHeader("msg-ttl", self.msg_ttl)
		self._addHeader("version", self.version)

	def _buildinfoxml(self):
		self.info = etree.SubElement(self.root, "info")

	def __str__(self):
		self._buildxml()
		x = etree.tostring(self.root)
		if self.infoxml is not None:
			return x.replace('<info />', self.infoxml, 1)
		return x

	def _addHeader(self, key, value):
		etree.SubElement(self.header, key).text = value

	def tostring(self):
		return self.__str__()

class AuthenticatedRequest(Request):
	def __init__(self, hv, methodcall, usertoken=None, infoxml=None, recordid=None):
		Request.__init__(self, hv, methodcall)
		if not hv.authenticated:
			raise Exception("Cannot construct AuthenticatedRequest when not authenticated to the HealthVault platform yet!")
		self.authentication = True 
		self.usertoken = usertoken
		self.infoxml = infoxml
		self.recordid = recordid

class AuthenticationRequest(Request):

	sharedSecret = None

	def __init__(self, hv):
		Request.__init__(self, hv, "CreateAuthenticatedSessionToken")
		rand = str(M2Crypto.BN.rand(2048, -1, False))
		self.sharedSecret = hashlib.sha1(rand).hexdigest()
		self.authentication = False

	def getSharedSecret(self):
		return self.sharedSecret

	def _buildinfoxml(self):
		Request._buildinfoxml(self)
		
		key = M2Crypto.RSA.load_key(self.hv.pemfile, lambda x:"")

		sharedsecretb64 = base64.b64encode(self.sharedSecret)
		contentnew='<content><app-id>'+self.hv.applicationid+'</app-id><shared-secret><hmac-alg algName="HMACSHA1">'+sharedsecretb64+'</hmac-alg></shared-secret></content>'
  		
		base64signedcontentnew = base64.b64encode(key.sign(hashlib.sha1(contentnew).digest()))

		signature = base64signedcontentnew 
		thumbprint = open(self.hv.fpfile, 'r').readline().rstrip()

		authinfo = etree.SubElement(self.info, "auth-info")
		etree.SubElement(authinfo, "app-id").text = self.hv.applicationid
		credential = etree.SubElement(authinfo, "credential")
		appserver = etree.SubElement(credential, "appserver")
		etree.SubElement(appserver, "sig", 
			attrib = {
				"digestMethod":"SHA1",
				"sigMethod":"RSA-SHA1",
				"thumbprint":thumbprint
			}
		).text = signature
		content = etree.SubElement(appserver, "content")
		etree.SubElement(content, "app-id").text = self.hv.applicationid
		sharedsecret = etree.SubElement(content, "shared-secret")
		etree.SubElement(sharedsecret, "hmac-alg", 
			attrib = { "algName": "HMACSHA1"}
		).text = sharedsecretb64
	
class AuthenticationRequest2(Request):
	sharedSecret = None

	def __init__(self, hv):
		Request.__init__(self, hv, "CreateAuthenticatedSessionToken")
		rand = str(M2Crypto.BN.rand(2048, -1, False))
		self.sharedSecret = hashlib.sha1(rand).hexdigest()
		self.authentication = False

	def getSharedSecret(self):
		return self.sharedSecret

	def _buildinfoxml(self):
		Request._buildinfoxml(self)
		
		key = M2Crypto.RSA.load_key(self.hv.pemfile, lambda x:"")

		sharedsecretb64 = base64.b64encode(self.sharedSecret)
		self.hv.applicationid = "5482e120-4bd4-48d9-b834-31b7100fb13f"
		contentnew='<content><app-id>'+self.hv.applicationid+'</app-id><shared-secret><hmac-alg algName="HMACSHA1">'+sharedsecretb64+'</hmac-alg></shared-secret></content>'
  		
		base64signedcontentnew = base64.b64encode(key.sign(hashlib.sha1(contentnew).digest()))

		signature = base64signedcontentnew 
		thumbprint = open(self.hv.fpfile, 'r').readline().rstrip()

		authinfo = etree.SubElement(self.info, "auth-info")
		etree.SubElement(authinfo, "app-id").text = self.hv.applicationid
		credential = etree.SubElement(authinfo, "credential")
		appserver = etree.SubElement(credential, "appserver")
		etree.SubElement(appserver, "sig", 
			attrib = {
				"digestMethod":"SHA1",
				"sigMethod":"RSA-SHA1",
				"thumbprint":thumbprint
			}
		).text = signature
		content = etree.SubElement(appserver, "content")
		etree.SubElement(content, "app-id").text = self.hv.applicationid
		sharedsecret = etree.SubElement(content, "shared-secret")
		etree.SubElement(sharedsecret, "hmac-alg", 
			attrib = { "algName": "HMACSHA1"}
		).text = sharedsecretb64

