//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Copyright (C) Microsoft Corporation. All Rights Reserved.
//
// Microsoft Health Solutions Group.
//
//----------------------------------------------------------------------------

import urllib2, string
import request, response, windowslive, things
import xml.etree.ElementTree as etree 
import xml.dom.minidom
from xml.dom.minidom import parseString

class HealthVault():

	def __init__(self, applicationid=None, serviceurl=None,pemfile=None,fpfile=None,shellredirecturl=None, cookiejar=None):
		self.applicationid = applicationid
		self.pemfile = pemfile
		self.fpfile = fpfile
		self.shellredirecturl = shellredirecturl
		self.serviceurl = serviceurl
		self.authenticated = False 

	def getWindowsLiveUser(self, username, password):
		return windowslive.WindowsLiveUser(self, username, password)
	
	def setSharedSecret(self, sharedsecret):
		self.sharedsecret = sharedsecret
	def getSharedSecret(self):
		return self.sharedsecret
	def setSessionToken(self,sessiontoken):
		self.sessiontoken = sessiontoken
	def getSessionToken(self):
		return self.sessiontoken
	def setAuthenticated(self, authenticated=False):
		self.authenticated = True
	
	def acquireSessionToken(self):
		self.authenticated = False
		req = request.AuthenticationRequest(self)	
		sharedsecret = req.getSharedSecret()
		res = self.sendRequest(req)
		if res.isError:
			raise Exception("Cannot acquire session token!\r\n%s" % res)
		token = res.tree.find("{urn:com.microsoft.wc.methods.response.CreateAuthenticatedSessionToken}info/token") 
		if token is None:
			raise Exception("No error in request but still no token found either!")
		self.sharedsecret = sharedsecret
		self.sessiontoken = token.text
		self.authenticated = True
		return True

	def acquireSessionToken2(self):
		self.authenticated = False
		req = request.AuthenticationRequest2(self)	
		sharedsecret = req.getSharedSecret()
		res = self.sendRequest(req)
		if res.isError:
			raise Exception("Cannot acquire session token!\r\n%s" % res)
		token = res.tree.find("{urn:com.microsoft.wc.methods.response.CreateAuthenticatedSessionToken}info/token") 
		if token is None:
			raise Exception("No error in request but still no token found either!")
		self.sharedsecret = sharedsecret
		self.sessiontoken = token.text
		self.authenticated = True
		return True

	def sendRequest(self, req):
		data = req.tostring()
		headers = {"Content-Type" : "text/xml"}
		ureq = urllib2.Request(self.serviceurl, data, headers)
		res = urllib2.urlopen(ureq)
		return response.Response(res)

	def getApplicationSettings(self, user):
		req = request.AuthenticatedRequest(self, "GetApplicationSettings", user.usertoken)
		res = self.sendRequest(req)
		return res

	def getServiceDefinition(self):
		req = request.Request(self, "GetServiceDefinition")
		res = self.sendRequest(req)
		return xml.dom.minidom.parseString(res.xmlContents).toprettyxml()

	def getPersonInfo(self, user):
		req = request.AuthenticatedRequest(self, "GetPersonInfo", user.usertoken)
		res = self.sendRequest(req)
		return res

	def getDefaultRecordForUser(self, user):
		req = request.AuthenticatedRequest(self, "GetPersonInfo", user.usertoken)
		res = self.sendRequest(req)
		if res.isError:
			raise Exception("%s" % res)
			
		token = res.tree.find("{urn:com.microsoft.wc.methods.response.GetPersonInfo}info/person-info/selected-record-id") 
		if token is None:
			raise Exception("No selected-record-id (default record) for the user found")
		return token.text

	def connectPackage(self, friendlyname, question, recordid, package):
		package = package[len("<thing>"):-len("</thing>")]
		recordid="6edb1e7d-f7be-42be-a3a0-39cfdab5f2e5"
		import base64
		package = "<type-id>c9287326-bb43-4194-858c-8b60768f000f</type-id><thing-state>Active</thing-state><data-xml><password-protected-package><encrypt-algorithm><algorithm-name>hmac-sha1-3des</algorithm-name><parameters><salt>AAAAAAAAAAAA</salt><iteration-count>20000</iteration-count><key-length>192</key-length></parameters></encrypt-algorithm></password-protected-package><common /></data-xml><data-other>%s</data-other>" % base64.b64encode("FLFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFOP")
		infoxml = "<info><friendly-name>%s</friendly-name><question>%s</question><external-id>%s</external-id><package>%s</package></info>" % (friendlyname, question, recordid, package)
		req = request.AuthenticatedRequest(self, "CreateConnectPackage", infoxml=infoxml)
		res = self.sendRequest(req)
		if res.isError:
			raise Exception("%s" % res)
		token = res.tree.find("{urn:com.microsoft.wc.methods.response.CreateConnectPackage}info/identity-code")
		if token is None:
			raise Exception("Cannot find identity id in the response!")
		return token.text

	def getApplicationInfo(self, user):
		req = request.AuthenticatedRequest(self, "GetApplicationInfo", user.usertoken)
		res = self.sendRequest(req)
		return res

	def updateApplication(self, user, name, actionurl):
		infoxml = "<info><application><id>%s</id><name>%s</name><action-url>%s</action-url></application></info>" % (self.applicationid, name, actionurl)
		req = request.AuthenticatedRequest(self, "UpdateApplication", usertoken=user.usertoken, infoxml=infoxml)
		req.methodversion = "2"
		res = self.sendRequest(req)
		return res
		
		
	def sendMessage(self, subject, message, users, ruser):
		info = etree.Element("info")
		for user in users:
			rcpt = etree.SubElement(info, "rcpt-address")
			etree.SubElement(rcpt, "address").text = user["email"]
			etree.SubElement(rcpt, "name").text = user["name"]
		#etree.SubElement(info, "rcpt-person", attrib={"validated":"false"}).text = "2b177007-017f-45e3-8477-4edc0dc1a515"
		#etree.SubElement(info, "rcpt-record", attrib={"validated":"false"})
		#.text = "2b177007-017f-45e3-8477-4edc0dc1a515"

		etree.SubElement(info, "subject").text = subject
		etree.SubElement(info, "text-body").text = message
		
		infoxml = etree.tostring(info)
		req = request.AuthenticatedRequest(self, "SendInsecureMessage", usertoken=ruser.usertoken, infoxml=infoxml)
		print req
		res = self.sendRequest(req)
		print res
			

	def putThings(self, user, recordid, things):
		infoxml = "<info>%s</info>" % string.join([t.toxml() for t in things],'')
		req = request.AuthenticatedRequest(self, "PutThings", 
			usertoken = user.usertoken, 
			recordid = recordid,
			infoxml = infoxml
		)
		res = self.sendRequest(req)
		if res.isError:
			print res
		else:
			print res.xmlContents

	def getThings(self, user, recordid):
		infoxml = "<info><group max=\"5\"><filter><type-id>%s</type-id><thing-state>Active</thing-state></filter><format><section>core</section><xml>form</xml></format></group></info>" % things.WEIGHT_THING_GUID
		req = request.AuthenticatedRequest(self, "GetThings",
			usertoken = user.usertoken, 
			recordid = recordid,
			infoxml = infoxml
		)
		res = self.sendRequest(req)
		print req
		if res.isError:
			print res
		else:
			print res.xmlContents
		
		
	def createOpenQuery(self, user, recordid):
		expires = 10 # in minutes
		pincode = "123"
		note = "This is a small note on the open query"
		method = "GetThings"
		extrainfo = "<group max=\"5\"><filter><type-id>%s</type-id><thing-state>Active</thing-state></filter><format><section>core</section><xml /></format></group>" % things.CCR_THING_GUID
		infoxml = "<info><expires>%i</expires><pin-code>%s</pin-code><note>%s</note><method>%s</method><method-version>1</method-version><record-id>%s</record-id><info>%s</info></info>" % \
			 (expires, pincode, note, method, recordid, extrainfo)	
		req = request.AuthenticatedRequest(self, "GetMethodMaskCache", 
			usertoken = user.usertoken, 
			recordid = recordid,
			infoxml = infoxml
		)
		res = self.sendRequest(req)
		if res.isError:
			print res
		else:
			print res.xmlContents
