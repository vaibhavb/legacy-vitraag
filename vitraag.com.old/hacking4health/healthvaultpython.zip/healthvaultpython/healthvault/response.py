//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Copyright (C) Microsoft Corporation. All Rights Reserved.
//
// Microsoft Health Solutions Group.
//
//----------------------------------------------------------------------------

import xml.etree.ElementTree as etree

class Response:
	xmlContents = None

	errorCode = None
	errorMessage = None
	isError = False

	def __init__(self, xml):
		self.tree = tree = etree.ElementTree()
		tree.parse(xml)
		errorel = tree.find("status/error")
		if errorel is not None:
			self.isError = True
			self.errorCode = tree.find("status/code").text
			self.errorMessage = errorel.find("message").text
		else:
			self.xmlContents = etree.tostring(tree.getroot())

	def __str__(self):
		if self.isError:
			return "Code(%s): %s" % (self.errorCode, self.errorMessage)
		else:
			return self.xmlContents
