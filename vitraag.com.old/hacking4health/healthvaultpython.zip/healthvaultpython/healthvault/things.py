//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// Copyright (C) Microsoft Corporation. All Rights Reserved.
//
// Microsoft Health Solutions Group.
//
//----------------------------------------------------------------------------

import xml.etree.ElementTree as etree 
import base64, hmac, hashlib
import M2Crypto

# define global guids
CCD_THING_GUID = "9c48a2b8-952c-4f5a-935d-f3292326bf54"
CCR_THING_GUID = "1e1ccbfc-a55d-4d91-8940-fa2fbf73c195"
WEIGHT_THING_GUID = "3d34d87e-7fc1-4153-800f-f56592cb0d17"
FILE_THING_GUID = "bd0403c5-4ae2-4b0e-a8db-1888678e4528"
PACKAGE_THING_GUID = "c9287326-bb43-4194-858c-8b60768f000f"

class Thing:

	thingtype = None

	def __init__(self, thingtype):
		self.thingtype = thingtype 

	def toxml(self):
		self.thingxml = etree.Element("thing") 
		etree.SubElement(self.thingxml, "type-id").text = self.thingtype 	
		self.dataxml = etree.SubElement(self.thingxml, "data-xml")
		self._toxml()
		return etree.tostring(self.thingxml)

	def _toxml(self):
		raise Exception("Should be overridden by child classes!")

class FileThing(Thing):

	filecontents = None

	def __init__(self, file, filename, filesize, contenttype):
		Thing.__init__(self, FILE_THING_GUID)
		fd = open(file, 'r')
		self.filecontents = fd.read()
		self.filename = filename
		self.filesize = str(filesize)
		self.contenttype = contenttype
		fd.close()

	def _toxml(self):
		file = etree.SubElement(self.dataxml, "file")
		etree.SubElement(file, "name").text = self.filename
		etree.SubElement(file, "size").text = self.filesize 
		contenttype = etree.SubElement(file, "content-type")
		etree.SubElement(contenttype, "text").text = self.contenttype
		dataother = etree.SubElement(self.thingxml, "data-other", attrib={"content-type":self.contenttype, "content-encoding":"base64"}).text = base64.b64encode(self.filecontents)

class CCDFileThing(Thing):

	filecontents = None

	def __init__(self, file):
		Thing.__init__(self, CCD_THING_GUID) 
		fd = open(file, 'r')
		self.filecontents = u''+fd.read()
		fd.close()

	def toxml(self):
		return "<thing><type-id>%s</type-id><data-xml>%s</data-xml></thing>" % (CCD_THING_GUID, self.filecontents)

class CCRFileThing(Thing):
	filecontents = None

	def __init__(self, file):
		Thing.__init__(self, CCR_THING_GUID) 
		fd = open(file, 'r')
		self.filecontents = u''+fd.read()
		fd.close()

	def toxml(self):
		return "<thing><type-id>%s</type-id><data-xml>%s</data-xml></thing>" % (CCR_THING_GUID, self.filecontents)
	

class PasswordProtectedPackage(Thing):
	def __init__(self):
		Thing.__init__(self, PACKAGE_THING_GUID) 
	def toxml(self):
		algo = "hmac-sha256-aes256"
		salt = "SALT"
		iterationcount = 20000
		keylength = 32 
		password = "WORLD"
		inputdata = "HELLO"

		msghmac = hmac.new(salt, '', hashlib.sha256)
		msghmac.update(inputdata)
		hmacmsg = msghmac.digest()

		rdbytes = M2Crypto.EVP.pbkdf2(password, salt, iterationcount, keylen=keylength)
		key = iv = rdbytes

		cipher = M2Crypto.EVP.Cipher(alg="aes_256_cbc", key=key, iv=iv, op=1)
		crypteddata = cipher.update(inputdata)
		crypteddata += cipher.final()
		
		data = base64.b64encode(crypteddata)
		pkg = etree.Element("password-protected-package") 
		alg = etree.SubElement(pkg, "encrypt-algorithm")
		etree.SubElement(alg, "algorithm-name").text = algo 
		params = etree.SubElement(alg, "parameters")
		etree.SubElement(params, "salt").text = salt
		etree.SubElement(params, "iteration-count").text = str(iterationcount)
		etree.SubElement(params, "key-length").text = str(keylength)

		
		contents = etree.tostring(pkg)
		return "<thing><type-id>%s</type-id><data-xml>%s</data-xml><data-other>%s</data-other></thing>" % (PACKAGE_THING_GUID, contents, data)

class TransformThingTest(Thing):
	filecontents = None

	def __init__(self):
		Thing.__init__(self, FILE_THING_GUID) 
		self.filecontents = '<flop></flop>' 

	def toxml(self):
		return "<thing><type-id>%s</type-id><data-xml transform=\"\">%s</data-xml></thing>" % (CCR_THING_GUID, self.filecontents)

		
